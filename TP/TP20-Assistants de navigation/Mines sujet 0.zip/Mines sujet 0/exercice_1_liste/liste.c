#include "liste.h"

// Renvoie un pointeur vers la liste qui contient les éléments
// contenus dans la liste a plus la paire (n,d).
struct liste_voisin * ajoute(struct liste_voisin * a, int n, double d) {
    // À compléter
}

int taille_liste(struct liste_voisin * a) {
  // À compléter
}
