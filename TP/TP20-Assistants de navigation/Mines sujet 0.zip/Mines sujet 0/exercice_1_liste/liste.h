#ifndef LISTE_H
#define LISTE_H

#include <stdlib.h>

struct liste_voisin {
  // À compléter
};

struct liste_voisin * ajoute(struct liste_voisin *, int, double);
int taille_liste(struct liste_voisin *);


#endif
