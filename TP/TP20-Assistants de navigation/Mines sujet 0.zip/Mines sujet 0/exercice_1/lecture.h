#ifndef LECTURE_H
#define LECTURE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct geopoint {
  double latitude, longitude ;
};


extern struct geopoint * position ;
extern int nb_routes ;

void lit_routes(void) ;
void lit_positions(void) ;
void nettoie(void);

#endif
