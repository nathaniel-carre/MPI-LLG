open Tp13_outils

type image = int array array
type data = image array * int array

let lire_donnees (fichier: string) : data =
    failwith "À modifier"

let delta (im1: image) (im2: image) : int =
    failwith "À modifier"

let plus_proches_voisins (k: int) ((xtrain, ytrain): data) (im: image) : int array =
    failwith "À modifier"

let majoritaire (etiq: int array) : int =
    failwith "À modifier"

let kppv (k: int) (train: data) (im: image) =
    failwith "À modifier"

let matrice_confusion (k: int) (train: data) ((xtest, ytest): data) : int array array =
    failwith "À modifier"

let taux_erreur (confu: int array array) : float =
    failwith "À modifier"

type rgb = int array
type image_couleur = rgb array array

let delta_rgb (p1: rgb) (p2: rgb) : int =
    failwith "À modifier"

let selection_bary (k: int) (im: image_couleur) : rgb array =
    failwith "À modifier"

let bary_plus_proche (bary: rgb array) (p: rgb) : int =
    failwith "À modifier"

let maj_classes (im: image_couleur) (bary: rgb array) (classes: int array array) : bool =
    failwith "À modifier"

let ( ++ ) (p1: rgb) (p2: rgb) : rgb = [|p1.(0) + p2.(0); p1.(1) + p2.(1); p1.(2) + p2.(2)|]

let ( -- ) (p1: rgb) (p2: rgb) : rgb = failwith "À modifier"

let ( ** ) (p: rgb) (a: int) : rgb = failwith "À modifier"

let ( // ) (p: rgb) (a: int) : rgb = failwith "À modifier"

let maj_bary (im: image_couleur) (bary: rgb array) (classes: int array array) : unit =
    failwith "À modifier"

let kmoyennes (k: int) (im: image_couleur) : rgb array * int array array =
    failwith "À modifier"

let reconstruire (im: image_couleur) (bary: rgb array) (classes: int array array) : image_couleur =
    failwith "À modifier"

let floyd_steinberg (im: image_couleur) (bary: rgb array) : image_couleur =
    failwith "À modifier"