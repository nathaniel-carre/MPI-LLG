Source des données :

       https://www.kaggle.com/datasets/nageshsingh/dna-sequence-dataset/data
