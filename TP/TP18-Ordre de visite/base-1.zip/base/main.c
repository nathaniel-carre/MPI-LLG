#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "utils.h"
#include "graphe.h"

int main() {
  printf("Initialisation du programme...");
  size_t nombregraphes;
  p_graphe* graphes = NULL;
  graphes = lecturefichier("graphes.txt", &nombregraphes);
  printf(" %zu graphes chargés depuis le fichier.\n",nombregraphes);
  
  printf("Affichage du premier graphe à titre d'exemple :\n");
  affichergraphe(graphes[0]);

  /* Implémentez vos algorithmes dans ce fichier, nous vous recommendons 
   * de ne *pas* utiliser de fichiers auxilliaires afin d'éviter de devoir 
   * modifier le makefile.
   *
   * Vous pouvez être amené à devoir modifier la structure du graphe 
   * cf. graphe.h et graphe.c pour les initialisations si besoin.
   *
   * Pensez à bien copier les fichiers qui vous ont été fournis, en effet, 
   * il serait dommage de les supprimer par erreur.
   * */

  return 0;
}
