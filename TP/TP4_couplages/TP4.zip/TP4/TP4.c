#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "utilitaire.h"

int* creer_tab(int k, int val){
    // À compléter.
    return NULL;
}

int cardinal_couplage(graphe G, int* C){
    // À compléter.
    return 0;
}

int* accessibles(graphe G, int s){
    // À compléter.
    return NULL;
}

int calcul_nX(graphe G){
    // À compléter.
    return 0;
}

graphe graphe_augmentation(graphe G, int nX, int* C){
    // À compléter.
    graphe GA = {.n=0, .adj=NULL};
    return GA;
}

liste* chemin_augmentant(graphe G, int nX, int* C){
    // À compléter.
    return NULL;
}

void augmenter(int* C, liste* sigma){
    // À compléter.
    return;
}

int* couplage_maximum(graphe G){
    // À compléter.
    return NULL;
}

int* bfs_alternant(graphe G, int nX, int* C, int* dist){
    // À compléter.
    return NULL;
}

liste* dfs_alternant(graphe G, int* C, int* dist, bool* vus, int y){
    // À compléter.
    return NULL;
}

int* hopcroft_karp(graphe G){
    // À compléter.
    return NULL;
}

int main(void){
    graphe G1 = generer_biparti(6, 6, 3, 11);

    for (int s=0; s<6; s++){
        printf("Sommet %d : ", s);
        afficher_liste(G1.adj[s]);
    }

    graphe G2 = generer_biparti(100, 100, 5, 1);
    graphe G3 = generer_biparti(5000, 5000, 10, 42);

    liberer_graphe(G1);
    liberer_graphe(G2);
    liberer_graphe(G3);
    return 0;
}