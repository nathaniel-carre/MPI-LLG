#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>



struct TTT {
    int n;
    int k;
    int* grille;
};
 
typedef struct TTT ttt;

ttt init_jeu(int k, int n){
    ttt jeu;
    return jeu;
}

int* repartition(ttt jeu){
    return NULL;
}

int joueur_courant(ttt jeu){
    return 0;
}

void jouer_coup(ttt jeu, int lgn, int cln){
    return;
}

bool alignement(ttt jeu, int i, int di, int joueur){
    return false;
}

bool gagnant(ttt jeu, int joueur){
    return false;
}

int encodage(ttt jeu){
    return 0;
}

// int attracteur(ttt jeu, dict* D);

// int strategie_optimale(ttt jeu, dict* D);

void afficher(ttt jeu){
    return;
}

void jouer_partie(int k, int n){
    return;
}

int main(void){
    return 0;
}