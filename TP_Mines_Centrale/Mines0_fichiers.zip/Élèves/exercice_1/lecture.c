#include "lecture.h"


struct geopoint * position ;
int nb_routes ;


void lit_routes() {
  FILE * fp = fopen ("routes.txt", "r"); // ouvre le fichier routes.txt en lecture

  
  fscanf(fp,"%d",&nb_routes); // lit la première ligne
  // qui donne le nombre de lignes dans le fichier
  
  for(int id_route = 0 ; id_route < nb_routes ; id_route++ ) {  // itère pour chaque ligne
    int depart, arrivee;
    double distance ;
    char nomRoute[270];
    fscanf(fp,"%d %d %lf  %[^\n]\n",&depart,&arrivee,&distance,nomRoute);
    // lit une ligne et stocke le résultat dans les variables passées
    // en paramètre. On sait donc qu'il y a un segment de route de
    // depart à fin de longueur distance et la route s'appelle nomRoute
  }
  fclose(fp); // ferme le fichier routes.txt
}

void lit_positions() {
  // on rappelle que fscanf(fp,"%lf %lf\n",longitude,latitude);
  // lit une paire de coordonnées sur une ligne 
}

void nettoie() {
  // cette fonction est appelée une fois de la fonction main et doit
  // libérer toute la mémoire allouée
}
