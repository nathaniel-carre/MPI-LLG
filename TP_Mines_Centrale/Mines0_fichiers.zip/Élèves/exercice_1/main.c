#include "lecture.h"

const double DEGREE_VERS_RADIAN = M_PI / 180 ;
const double DIAMETRE_TERRE_EN_KM = 12742 ;

double ll_distance(struct geopoint p1, struct geopoint p2) {
  // À compléter
}

int main() {
  lit_positions();
  lit_routes();
  nettoie();
  return 0;
}
